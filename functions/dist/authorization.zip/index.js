"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.asd = void 0;
exports.asd = 'asd';
